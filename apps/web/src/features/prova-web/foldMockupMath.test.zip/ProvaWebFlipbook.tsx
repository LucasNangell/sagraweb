import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Maximize2,
  Minimize2,
  ZoomIn,
} from "lucide-react";
import { PageFlip } from "page-flip";
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

import {
  provaWebPageUrl,
  type ProvaWebManifestBase,
  type ProvaWebPageMeta,
} from "@/api/provaWeb";

import "./prova-web.css";

interface ProvaWebFlipbookProps {
  ano: number;
  osId: number;
  manifest: ProvaWebManifestBase;
  /** Sobrescreve a URL das páginas (ex.: portal do cliente, com token). */
  buildPageUrl?: (page: number) => string;
}

/** Altura reservada para header + toolbar ao dimensionar o livro. */
const CHROME_HEIGHT_PX = 190;
const EAGER_BEFORE = 2;
const EAGER_AFTER = 3;

export function ProvaWebFlipbook({
  ano,
  osId,
  manifest,
  buildPageUrl,
}: ProvaWebFlipbookProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const bookRef = useRef<HTMLDivElement>(null);
  const flipRef = useRef<PageFlip | null>(null);
  const jumpInputRef = useRef<HTMLInputElement>(null);
  const jumpFocusedRef = useRef(false);

  const [pageIndex, setPageIndex] = useState(0);
  const [zoomOpen, setZoomOpen] = useState(false);
  const [jumpDraft, setJumpDraft] = useState("1");
  const [loadedSrc, setLoadedSrc] = useState<Record<number, string>>({});
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [cssFullscreen, setCssFullscreen] = useState(false);

  const pages = manifest.pages;
  const total = pages.length;
  const cacheKey = manifest.cacheKey;

  const pageUrl = useCallback(
    (page: ProvaWebPageMeta) => {
      if (buildPageUrl) {
        return buildPageUrl(page.page);
      }
      return provaWebPageUrl(ano, osId, page.page, cacheKey);
    },
    [ano, buildPageUrl, cacheKey, osId],
  );

  const baseSize = useMemo(() => {
    const first = pages.find((p) => p.role === "page") ?? pages[0];
    const width = first?.width || 800;
    const height = first?.height || 1130;
    const availableH = Math.max(
      320,
      (typeof window !== "undefined" ? window.innerHeight : 900) -
        CHROME_HEIGHT_PX,
    );
    const scale = Math.min(1, availableH / height);
    return {
      width: Math.max(160, Math.round(width * scale)),
      height: Math.max(220, Math.round(height * scale)),
    };
  }, [pages]);

  // Progressive: fill src for window around pageIndex (sticky once loaded).
  useEffect(() => {
    if (total === 0) return;
    setLoadedSrc((prev) => {
      const next = { ...prev };
      let changed = false;
      const lo = Math.max(0, pageIndex - EAGER_BEFORE);
      const hi = Math.min(total - 1, pageIndex + EAGER_AFTER);
      for (let i = lo; i <= hi; i++) {
        const page = pages[i];
        if (!page || next[page.page]) continue;
        next[page.page] = pageUrl(page);
        changed = true;
      }
      // Always warm covers
      for (const page of pages) {
        if (
          (page.role === "cover-front" || page.role === "cover-back") &&
          !next[page.page]
        ) {
          next[page.page] = pageUrl(page);
          changed = true;
        }
      }
      return changed ? next : prev;
    });
  }, [pageIndex, pageUrl, pages, total]);

  // Reset loaded map when cache changes
  useEffect(() => {
    setLoadedSrc({});
    setPageIndex(0);
    setJumpDraft("1");
  }, [cacheKey]);

  useEffect(() => {
    const el = bookRef.current;
    if (!el || total === 0) {
      return;
    }

    const flip = new PageFlip(el, {
      width: baseSize.width,
      height: baseSize.height,
      size: "stretch",
      minWidth: Math.round(baseSize.width / 4),
      maxWidth: baseSize.width * 2,
      minHeight: Math.round(baseSize.height / 4),
      maxHeight: baseSize.height * 2,
      showCover: true,
      maxShadowOpacity: 0.5,
      flippingTime: 600,
      mobileScrollSupport: false,
      showPageCorners: true,
    });

    flip.loadFromHTML(el.querySelectorAll<HTMLElement>(".prova-web-page"));
    flip.on("flip", (e) => {
      const idx = Number(e.data);
      setPageIndex(Number.isFinite(idx) ? idx : 0);
    });
    flipRef.current = flip;

    return () => {
      flipRef.current = null;
      try {
        flip.destroy();
      } catch {
        // instância já removida do DOM
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [manifest.cacheKey, total]);

  // Sync jump field when not focused
  useEffect(() => {
    if (jumpFocusedRef.current) return;
    const visible = resolveVisiblePages(pages, pageIndex);
    const first = visible[0];
    if (first) {
      setJumpDraft(String(first.page));
    }
  }, [pageIndex, pages]);

  const goPrev = useCallback(() => flipRef.current?.flipPrev(), []);
  const goNext = useCallback(() => flipRef.current?.flipNext(), []);
  const goStart = useCallback(() => flipRef.current?.turnToPage(0), []);
  const goEnd = useCallback(() => {
    const flip = flipRef.current;
    if (flip) {
      flip.turnToPage(flip.getPageCount() - 1);
    }
  }, []);

  const goToPageNumber = useCallback(
    (raw: string) => {
      const n = Number.parseInt(raw, 10);
      if (!Number.isFinite(n) || total < 1) return;
      const pageMeta = pages.find((p) => p.page === n);
      const idx = pageMeta
        ? pages.indexOf(pageMeta)
        : Math.max(0, Math.min(total - 1, n - 1));
      flipRef.current?.turnToPage(idx);
      setJumpDraft(String(pages[idx]?.page ?? n));
    },
    [pages, total],
  );

  const exitCssFullscreen = useCallback(() => setCssFullscreen(false), []);

  const toggleFullscreen = useCallback(async () => {
    const el = rootRef.current;
    if (!el) return;

    if (document.fullscreenElement === el) {
      await document.exitFullscreen().catch(() => undefined);
      setIsFullscreen(false);
      return;
    }
    if (cssFullscreen) {
      setCssFullscreen(false);
      return;
    }

    try {
      if (el.requestFullscreen) {
        await el.requestFullscreen();
        setIsFullscreen(true);
        return;
      }
    } catch {
      // fallback CSS
    }
    setCssFullscreen(true);
  }, [cssFullscreen]);

  useEffect(() => {
    const onFs = () => {
      setIsFullscreen(document.fullscreenElement === rootRef.current);
    };
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (zoomOpen) {
        if (event.key === "Escape") {
          setZoomOpen(false);
        }
        return;
      }
      if (event.key === "Escape" && cssFullscreen) {
        exitCssFullscreen();
        return;
      }
      const target = event.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable)
      ) {
        return;
      }
      if (event.key === "ArrowRight" || event.key === "PageDown") {
        goNext();
      } else if (event.key === "ArrowLeft" || event.key === "PageUp") {
        goPrev();
      } else if (event.key === "Home") {
        goStart();
      } else if (event.key === "End") {
        goEnd();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [
    cssFullscreen,
    exitCssFullscreen,
    goEnd,
    goNext,
    goPrev,
    goStart,
    zoomOpen,
  ]);

  const visiblePages = useMemo(
    () => resolveVisiblePages(pages, pageIndex),
    [pages, pageIndex],
  );

  const fullscreenActive = isFullscreen || cssFullscreen;

  return (
    <div
      ref={rootRef}
      className={
        cssFullscreen
          ? "prova-web-flipbook-fs-fallback flex min-h-0 flex-1 flex-col bg-slate-200"
          : "flex min-h-0 flex-1 flex-col bg-slate-200/70"
      }
    >
      <div className="flex min-h-0 flex-1 items-center justify-center overflow-hidden px-4 py-4">
        <div className="w-full" style={{ maxWidth: baseSize.width * 2 + 40 }}>
          <div ref={bookRef} className="prova-web-book">
            {pages.map((page) => {
              const src = loadedSrc[page.page];
              return (
                <div
                  key={page.page}
                  className="prova-web-page"
                  data-density={
                    page.role === "cover-front" || page.role === "cover-back"
                      ? "hard"
                      : "soft"
                  }
                >
                  {src ? (
                    <img
                      src={src}
                      alt={pageAlt(page, total)}
                      loading="eager"
                      draggable={false}
                    />
                  ) : (
                    <div
                      className="prova-web-page-placeholder"
                      aria-hidden
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-2 border-t border-sagra-border bg-white px-4 py-3 shadow-sm">
        <ToolbarButton onClick={goStart} disabled={pageIndex <= 0} label="Início">
          <ChevronsLeft className="size-4" aria-hidden />
        </ToolbarButton>
        <ToolbarButton
          onClick={goPrev}
          disabled={pageIndex <= 0}
          label="Página anterior"
        >
          <ChevronLeft className="size-4" aria-hidden />
        </ToolbarButton>

        <span className="hidden min-w-36 select-none text-center text-xs font-medium tabular-nums text-neutral-600 sm:inline">
          {spreadLabel(pages, pageIndex)}
        </span>

        <label className="flex items-center gap-1 text-xs text-neutral-600">
          <span className="sr-only sm:not-sr-only sm:inline">Ir para</span>
          <input
            ref={jumpInputRef}
            type="number"
            min={1}
            max={total}
            value={jumpDraft}
            onFocus={() => {
              jumpFocusedRef.current = true;
            }}
            onBlur={() => {
              jumpFocusedRef.current = false;
              goToPageNumber(jumpDraft);
            }}
            onChange={(e) => setJumpDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                goToPageNumber(jumpDraft);
                jumpInputRef.current?.blur();
              }
            }}
            className="w-14 rounded-md border border-sagra-border bg-white px-1.5 py-1 text-center text-xs tabular-nums text-neutral-800"
            aria-label="Ir para página"
          />
          <span className="tabular-nums text-neutral-400">/ {total}</span>
        </label>

        <ToolbarButton
          onClick={goNext}
          disabled={pageIndex >= total - 1}
          label="Próxima página"
        >
          <ChevronRight className="size-4" aria-hidden />
        </ToolbarButton>
        <ToolbarButton
          onClick={goEnd}
          disabled={pageIndex >= total - 1}
          label="Fim"
        >
          <ChevronsRight className="size-4" aria-hidden />
        </ToolbarButton>

        <span className="mx-1 hidden h-5 w-px bg-sagra-border sm:inline" aria-hidden />

        <ToolbarButton onClick={() => setZoomOpen(true)} label="Ampliar páginas">
          <ZoomIn className="size-4" aria-hidden />
        </ToolbarButton>
        <ToolbarButton
          onClick={() => void toggleFullscreen()}
          label={fullscreenActive ? "Sair da tela cheia" : "Tela cheia"}
        >
          {fullscreenActive ? (
            <Minimize2 className="size-4" aria-hidden />
          ) : (
            <Maximize2 className="size-4" aria-hidden />
          )}
        </ToolbarButton>
      </div>

      {zoomOpen && (
        <div
          className="prova-web-zoom-backdrop"
          role="dialog"
          aria-label="Páginas ampliadas"
          onClick={() => setZoomOpen(false)}
        >
          <div
            className={
              visiblePages.length > 1
                ? "prova-web-zoom-spread"
                : "flex flex-wrap items-start justify-center gap-4"
            }
          >
            {visiblePages.map((page) => (
              <img
                key={page.page}
                src={loadedSrc[page.page] ?? pageUrl(page)}
                alt={pageAlt(page, total)}
                style={{ width: Math.min(page.width, 1200) }}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ToolbarButton({
  onClick,
  disabled,
  label,
  children,
}: {
  onClick: () => void;
  disabled?: boolean;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={label}
      aria-label={label}
      className="rounded-lg border border-sagra-border bg-white p-2 text-neutral-700 shadow-sm transition hover:bg-neutral-100 disabled:cursor-not-allowed disabled:opacity-30"
    >
      {children}
    </button>
  );
}

/** Páginas visíveis no spread atual (capa sozinha; miolo em pares). */
function resolveVisiblePages(
  pages: ProvaWebPageMeta[],
  pageIndex: number,
): ProvaWebPageMeta[] {
  const total = pages.length;
  if (total === 0) {
    return [];
  }
  if (pageIndex <= 0) {
    return [pages[0]];
  }
  if (pageIndex >= total - 1) {
    return [pages[total - 1]];
  }
  const left = pageIndex % 2 === 1 ? pageIndex : pageIndex - 1;
  return pages.slice(left, Math.min(left + 2, total - 1));
}

function spreadLabel(pages: ProvaWebPageMeta[], pageIndex: number): string {
  const total = pages.length;
  if (total === 0) {
    return "";
  }
  const visible = resolveVisiblePages(pages, pageIndex);
  const first = visible[0];
  const last = visible[visible.length - 1];
  if (first.role === "cover-front" && visible.length === 1) {
    return `Capa · ${total} páginas`;
  }
  if (last.role === "cover-back" && visible.length === 1) {
    return `Contracapa · ${total} páginas`;
  }
  if (visible.length === 2) {
    return `Páginas ${first.page}–${last.page} de ${total}`;
  }
  return `Página ${first.page} de ${total}`;
}

function pageAlt(page: ProvaWebPageMeta, total: number): string {
  if (page.blank) {
    return "Página em branco";
  }
  switch (page.role) {
    case "cover-front":
      return "Capa";
    case "cover-front-inside":
      return "Verso da capa";
    case "cover-back-inside":
      return "Verso da contracapa";
    case "cover-back":
      return "Contracapa";
    default:
      return `Página ${page.page} de ${total}`;
  }
}
