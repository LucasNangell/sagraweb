import {
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  UnfoldHorizontal,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import type { ProvaWebFoldMockupMeta, ProvaWebPageMeta } from "@/api/provaWeb";

import {
  createFoldScene,
  DEFAULT_ROT_X,
  DEFAULT_ROT_Y,
  MAX_ROT_X,
  ORBIT_SENS_X,
  ORBIT_SENS_Y,
  type FoldSceneHandle,
} from "./foldMockupThree";
import "./prova-web-fold-mockup.css";

export interface ProvaWebFoldMockup3DProps {
  pages: ProvaWebPageMeta[];
  foldMockup: ProvaWebFoldMockupMeta;
  pageUrl: (page: ProvaWebPageMeta) => string;
}

export function ProvaWebFoldMockup3D({
  pages,
  foldMockup,
  pageUrl,
}: ProvaWebFoldMockup3DProps) {
  const stageRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<FoldSceneHandle | null>(null);
  const rafRef = useRef<number>(0);
  const dragRef = useRef<{
    pointerId: number;
    x: number;
    y: number;
    rotY: number;
    rotX: number;
  } | null>(null);
  const rotRef = useRef({ x: DEFAULT_ROT_X, y: DEFAULT_ROT_Y });
  const unfoldRef = useRef(0);

  const [rotX, setRotX] = useState(DEFAULT_ROT_X);
  const [rotY, setRotY] = useState(DEFAULT_ROT_Y);
  const [unfold, setUnfold] = useState(0);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const front = useMemo(
    () =>
      pages.find((p) => p.role === "sheet-front" && !p.blank) ??
      pages.find((p) => !p.blank) ??
      null,
    [pages],
  );
  const back = useMemo(
    () => pages.find((p) => p.role === "sheet-back" && !p.blank) ?? null,
    [pages],
  );
  const frontUrl = front ? pageUrl(front) : null;
  const backUrl = foldMockup.hasVerso && back ? pageUrl(back) : null;

  const applyUnfold = useCallback((value: number) => {
    const v = Math.min(100, Math.max(0, value));
    unfoldRef.current = v;
    setUnfold(v);
    sceneRef.current?.setHingeAnglesFromUnfold(v / 100);
  }, []);

  const applyOrbit = useCallback((x: number, y: number) => {
    rotRef.current = { x, y };
    setRotX(x);
    setRotY(y);
    sceneRef.current?.setOrbit(x, y);
  }, []);

  // Build / rebuild scene when assets or geometry change
  useEffect(() => {
    const canvas = canvasRef.current;
    const stage = stageRef.current;
    if (!canvas || !stage) return;

    let cancelled = false;
    setReady(false);
    setError(null);

    void (async () => {
      try {
        sceneRef.current?.dispose();
        sceneRef.current = null;
        const handle = await createFoldScene(
          canvas,
          foldMockup,
          frontUrl,
          backUrl,
        );
        if (cancelled) {
          handle.dispose();
          return;
        }
        sceneRef.current = handle;
        handle.setOrbit(rotRef.current.x, rotRef.current.y);
        handle.setHingeAnglesFromUnfold(unfoldRef.current / 100);
        const rect = stage.getBoundingClientRect();
        handle.resize(rect.width, rect.height);
        setReady(true);

        const loop = () => {
          handle.render();
          rafRef.current = requestAnimationFrame(loop);
        };
        rafRef.current = requestAnimationFrame(loop);
      } catch (err) {
        if (!cancelled) {
          setError(
            err instanceof Error ? err.message : "Falha ao iniciar o mockup 3D.",
          );
        }
      }
    })();

    return () => {
      cancelled = true;
      cancelAnimationFrame(rafRef.current);
      sceneRef.current?.dispose();
      sceneRef.current = null;
    };
  }, [foldMockup, frontUrl, backUrl]);

  useEffect(() => {
    const stage = stageRef.current;
    if (!stage || !ready) return;
    const ro = new ResizeObserver(() => {
      const handle = sceneRef.current;
      if (!handle) return;
      const rect = stage.getBoundingClientRect();
      handle.resize(rect.width, Math.max(200, rect.height));
    });
    ro.observe(stage);
    const rect = stage.getBoundingClientRect();
    sceneRef.current?.resize(rect.width, Math.max(200, rect.height));
    return () => ro.disconnect();
  }, [ready]);

  const onPointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.button !== 0) return;
    const t = event.target as HTMLElement;
    if (t.closest("input,button,label")) return;
    if (!sceneRef.current) return;

    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = {
      pointerId: event.pointerId,
      x: event.clientX,
      y: event.clientY,
      rotY: rotRef.current.y,
      rotX: rotRef.current.x,
    };
  };

  const onPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const dx = event.clientX - drag.x;
    const dy = event.clientY - drag.y;
    // Arrastar esquerda → horário: rotY aumenta com dx negativo → rotY + dx
    const nextY = drag.rotY + dx * ORBIT_SENS_Y;
    const nextX = Math.max(
      -MAX_ROT_X,
      Math.min(MAX_ROT_X, drag.rotX + dy * ORBIT_SENS_X),
    );
    applyOrbit(nextX, nextY);
  };

  const endDrag = (event: React.PointerEvent<HTMLDivElement>) => {
    const drag = dragRef.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    dragRef.current = null;
    try {
      event.currentTarget.releasePointerCapture(event.pointerId);
    } catch {
      // already released
    }
  };

  const hingeCount = Math.max(
    1,
    new Set(foldMockup.hinges.map((h) => h.ordem)).size,
  );
  const stepUnfold = (dir: -1 | 1) => {
    const step = 100 / hingeCount;
    applyUnfold(Math.round(unfoldRef.current / step) * step + dir * step);
  };

  const resetView = () => {
    applyOrbit(DEFAULT_ROT_X, DEFAULT_ROT_Y);
  };

  const pageW = foldMockup.pageWidthMm;
  const pageH = foldMockup.pageHeightMm;

  return (
    <div
      className="prova-web-fold-mockup"
      role="img"
      aria-label="Mockup 3D do folheto dobrado"
    >
      <p className="prova-web-fold-mockup__hint">
        Arraste para girar · use o controle para desdobrar
      </p>

      <div className="prova-web-fold-mockup__toolbar">
        <button type="button" onClick={() => applyUnfold(0)} title="Fechar">
          Fechar
        </button>
        <button
          type="button"
          onClick={() => stepUnfold(-1)}
          title="Passo fechar"
          aria-label="Passo para fechar"
        >
          <ChevronLeft className="size-3.5" />
        </button>
        <label className="prova-web-fold-mockup__slider">
          <UnfoldHorizontal className="size-3.5 shrink-0" aria-hidden />
          <input
            type="range"
            min={0}
            max={100}
            step={1}
            value={unfold}
            onChange={(e) => applyUnfold(Number(e.target.value))}
            aria-label="Desdobrar"
          />
          <span className="tabular-nums">{Math.round(unfold)}%</span>
        </label>
        <button
          type="button"
          onClick={() => stepUnfold(1)}
          title="Passo abrir"
          aria-label="Passo para abrir"
        >
          <ChevronRight className="size-3.5" />
        </button>
        <button type="button" onClick={() => applyUnfold(100)} title="Abrir">
          Abrir
        </button>
        <button type="button" onClick={resetView} title="Resetar vista">
          <RotateCcw className="size-3.5" />
          Vista
        </button>
      </div>

      <div
        ref={stageRef}
        className="prova-web-fold-mockup__stage"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
      >
        <canvas
          ref={canvasRef}
          className="prova-web-fold-mockup__canvas"
          aria-hidden
        />
        {!ready && !error && (
          <p className="prova-web-fold-mockup__loading">Preparando mockup 3D…</p>
        )}
        {error && (
          <p className="prova-web-fold-mockup__loading text-sagra-danger">
            {error}
          </p>
        )}
      </div>

      <p className="prova-web-fold-mockup__meta">
        {foldMockup.preset} · {pageW.toFixed(0)}×{pageH.toFixed(0)} mm ·{" "}
        {foldMockup.panels.length} painéis
        {foldMockup.hasVerso ? " · com verso" : " · só frente"}
        {" · "}
        órbita {(rotY * (180 / Math.PI)).toFixed(0)}°/
        {(rotX * (180 / Math.PI)).toFixed(0)}°
        {foldMockup.panelPages && (
          <>
            {" · págs F "}
            {foldMockup.panelPages.frente.join("·")}
            {foldMockup.panelPages.verso
              ? ` / V ${foldMockup.panelPages.verso.join("·")}`
              : null}
          </>
        )}
      </p>
    </div>
  );
}
