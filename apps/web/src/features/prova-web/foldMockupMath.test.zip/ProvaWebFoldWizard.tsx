import { ArrowDown, ArrowLeft, ArrowUp, Loader2 } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import type {
  CropSidesMm,
  FoldDobra,
  FoldPresetId,
  FoldSentido,
  ProvaWebCropJson,
  ProvaWebFolhetoCrop,
} from "@/api/provaWeb";

import { ProvaWebCropPanel } from "./ProvaWebCropPanel";
import {
  applyPresetToFolheto,
  clampDobraPosicao,
  defaultFolhetoCrop,
  dobrasFromPreset,
  FOLD_LINE_COLORS,
  FOLD_PRESET_OPTIONS,
  panelCountFromDobras,
  syncSequenciaPaginas,
  usableAfterCrop,
} from "./provaWebFoldPresets";
import { useProvaWebCropMeta } from "./useProvaWebCropMeta";

export interface ProvaWebFoldWizardProps {
  ano: number;
  osId: number;
  arquivoUnico: string;
  saving?: boolean;
  onBack: () => void;
  onConfirm: (cropJson: ProvaWebCropJson) => void;
  formato?: string | null;
  formatoAlturaMm?: number | null;
  formatoLarguraMm?: number | null;
}

export function ProvaWebFoldWizard({
  ano,
  osId,
  arquivoUnico,
  saving = false,
  onBack,
  onConfirm,
  formato = null,
  formatoAlturaMm = null,
  formatoLarguraMm = null,
}: ProvaWebFoldWizardProps) {
  const [folheto, setFolheto] = useState<ProvaWebFolhetoCrop>(() =>
    defaultFolhetoCrop(),
  );
  const [previewPage, setPreviewPage] = useState(0);

  const metaQuery = useProvaWebCropMeta(ano, osId, arquivoUnico);
  const pageCount = metaQuery.data?.pageCount ?? 1;
  const pageMeta =
    metaQuery.data?.pages.find((p) => p.pageIndex === 0) ??
    metaQuery.data?.pages[0];
  const pageW = pageMeta?.widthMm ?? metaQuery.data?.widthMm ?? 210;
  const pageH = pageMeta?.heightMm ?? metaQuery.data?.heightMm ?? 297;

  const usable = useMemo(
    () => usableAfterCrop(pageW, pageH, folheto.crop),
    [pageW, pageH, folheto.crop],
  );

  const setCrop = useCallback(
    (crop: CropSidesMm) => {
      setFolheto((prev) => {
        const { w, h } = usableAfterCrop(pageW, pageH, crop);
        const prevUsable = usableAfterCrop(pageW, pageH, prev.crop);
        const dobras = prev.dobras.map((d) => {
          const span0 = d.eixo === "vertical" ? prevUsable.w : prevUsable.h;
          const span1 = d.eixo === "vertical" ? w : h;
          const frac = span0 > 0 ? d.posicaoMm / span0 : 0.5;
          return {
            ...d,
            posicaoMm: clampDobraPosicao(span1 * frac, d.eixo, w, h),
          };
        });
        return { ...prev, crop, dobras };
      });
    },
    [pageH, pageW],
  );

  const stableCrop = useCallback((c: CropSidesMm) => setCrop(c), [setCrop]);

  useEffect(() => {
    if (pageCount >= 2) {
      setFolheto((p) => {
        const hasVerso = true;
        const n = panelCountFromDobras(p.dobras);
        const next = p.pageVerso == null ? { ...p, pageVerso: 1 } : p;
        return {
          ...next,
          pageVerso: next.pageVerso ?? 1,
          sequenciaPaginas: syncSequenciaPaginas(
            next.sequenciaPaginas,
            n,
            hasVerso,
          ),
        };
      });
    } else {
      setFolheto((p) => {
        const n = panelCountFromDobras(p.dobras);
        return {
          ...p,
          pageVerso: null,
          sequenciaPaginas: syncSequenciaPaginas(
            p.sequenciaPaginas,
            n,
            false,
          ),
        };
      });
    }
  }, [pageCount]);

  const panelCount = useMemo(
    () => panelCountFromDobras(folheto.dobras),
    [folheto.dobras],
  );
  const hasVerso = pageCount >= 2 && folheto.pageVerso != null;
  const sequencia = useMemo(
    () =>
      syncSequenciaPaginas(
        folheto.sequenciaPaginas,
        panelCount,
        hasVerso,
      ),
    [folheto.sequenciaPaginas, panelCount, hasVerso],
  );

  const updateSeqSlot = (
    face: "frente" | "verso",
    index: number,
    value: number,
  ) => {
    setFolheto((prev) => {
      const n = panelCountFromDobras(prev.dobras);
      const base = syncSequenciaPaginas(
        prev.sequenciaPaginas,
        n,
        prev.pageVerso != null,
      );
      const nextFace = [...(face === "frente" ? base.frente : base.verso ?? [])];
      nextFace[index] = Math.max(1, Math.round(value) || 1);
      return {
        ...prev,
        sequenciaPaginas: {
          frente: face === "frente" ? nextFace : base.frente,
          verso:
            face === "verso"
              ? nextFace
              : prev.pageVerso != null
                ? base.verso
                : null,
        },
      };
    });
  };

  const seqDupes = useMemo(() => {
    const nums = [
      ...sequencia.frente,
      ...(sequencia.verso ?? []),
    ];
    const seen = new Set<number>();
    const dups = new Set<number>();
    for (const n of nums) {
      if (seen.has(n)) dups.add(n);
      seen.add(n);
    }
    return dups;
  }, [sequencia]);

  const sizedRef = useRef(false);
  useEffect(() => {
    if (!metaQuery.data || sizedRef.current) return;
    sizedRef.current = true;
    setFolheto((prev) =>
      applyPresetToFolheto(prev, prev.preset, pageW, pageH),
    );
  }, [metaQuery.data, pageW, pageH]);

  const cropJson: ProvaWebCropJson = useMemo(
    () => ({
      folheto: {
        ...folheto,
        pageFrente: folheto.pageFrente ?? 0,
        pageVerso: pageCount >= 2 ? (folheto.pageVerso ?? 1) : null,
        sequenciaPaginas: sequencia,
      },
    }),
    [folheto, pageCount, sequencia],
  );

  const selectPreset = (preset: FoldPresetId) => {
    setFolheto((prev) => applyPresetToFolheto(prev, preset, pageW, pageH));
  };

  const updateDobraPos = (id: string, posicaoMm: number) => {
    setFolheto((prev) => ({
      ...prev,
      dobras: prev.dobras.map((d) =>
        d.id === id
          ? {
              ...d,
              posicaoMm: clampDobraPosicao(
                posicaoMm,
                d.eixo,
                usable.w,
                usable.h,
              ),
            }
          : d,
      ),
    }));
  };

  const updateSentido = (id: string, sentido: FoldSentido) => {
    setFolheto((prev) => ({
      ...prev,
      dobras: prev.dobras.map((d) => (d.id === id ? { ...d, sentido } : d)),
    }));
  };

  const moveOrdem = (id: string, dir: -1 | 1) => {
    setFolheto((prev) => {
      const sorted = [...prev.dobras].sort((a, b) => a.ordem - b.ordem);
      const idx = sorted.findIndex((d) => d.id === id);
      const swap = idx + dir;
      if (idx < 0 || swap < 0 || swap >= sorted.length) return prev;
      const a = sorted[idx]!;
      const b = sorted[swap]!;
      const ordemA = a.ordem;
      return {
        ...prev,
        dobras: prev.dobras.map((d) => {
          if (d.id === a.id) return { ...d, ordem: b.ordem };
          if (d.id === b.id) return { ...d, ordem: ordemA };
          return d;
        }),
      };
    });
  };

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-1 flex-col gap-4 p-4">
      <div>
        <h2 className="text-sm font-semibold text-neutral-800">
          Assistente — Folheto dobrado
        </h2>
        <p className="mt-0.5 text-xs text-neutral-500">
          Crop, preset, marcas e sequência na mesma tela. Preview com vinco e
          crop em tempo real.
        </p>
      </div>

      {pageCount > 2 && (
        <p className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">
          Este PDF tem {pageCount} páginas. Serão usadas só as páginas 1
          (frente) e 2 (verso).
        </p>
      )}

      <div className="min-h-0 flex-1 space-y-5 overflow-y-auto pb-2">
        <section className="rounded-2xl border border-sagra-border bg-white p-4 shadow-sm">
          <h3 className="mb-3 text-sm font-semibold text-neutral-800">
            Crop e marcas de dobra
          </h3>
          <ProvaWebCropPanel
            ano={ano}
            osId={osId}
            relativePath={arquivoUnico}
            title="Crop da folha (mm)"
            crop={folheto.crop}
            onChange={stableCrop}
            pageIndex={previewPage}
            onPageIndexChange={setPreviewPage}
            showPageSelector={pageCount > 1}
            foldLines={folheto.dobras}
            onFoldPosicaoChange={updateDobraPos}
            formatoLabel={formato}
            formatoLarguraMm={formatoLarguraMm}
            formatoAlturaMm={formatoAlturaMm}
          />
        </section>

        <section className="space-y-3 rounded-2xl border border-sagra-border bg-white p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-neutral-800">
            Tipo de dobra
          </h3>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {FOLD_PRESET_OPTIONS.map((opt) => {
              const active = folheto.preset === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => selectPreset(opt.id)}
                  className={`rounded-xl border px-3 py-3 text-left transition ${
                    active
                      ? "border-primary-green bg-primary-green/10 ring-1 ring-primary-green/40"
                      : "border-sagra-border bg-slate-50 hover:bg-neutral-100"
                  }`}
                >
                  <PresetDiagram preset={opt.id} />
                  <p className="mt-2 text-sm font-medium text-neutral-800">
                    {opt.label}
                  </p>
                  <p className="text-[11px] text-neutral-500">{opt.hint}</p>
                </button>
              );
            })}
          </div>
        </section>

        <section className="space-y-3 rounded-2xl border border-sagra-border bg-white p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-neutral-800">
            Posições (mm na área útil)
          </h3>
          <div className="grid gap-2 sm:grid-cols-2">
            {folheto.dobras
              .slice()
              .sort((a, b) => a.ordem - b.ordem)
              .map((d, i) => {
                const span = d.eixo === "vertical" ? usable.w : usable.h;
                const distEnd = Math.round((span - d.posicaoMm) * 10) / 10;
                return (
                  <label
                    key={d.id}
                    className="flex flex-col gap-1 rounded-lg border border-sagra-border bg-slate-50 px-3 py-2 text-xs"
                  >
                    <span className="flex items-center gap-2 font-medium text-neutral-700">
                      <span
                        className="size-2 rounded-sm"
                        style={{
                          background:
                            FOLD_LINE_COLORS[i % FOLD_LINE_COLORS.length],
                        }}
                      />
                      Dobra {d.ordem} ·{" "}
                      {d.eixo === "vertical" ? "vertical" : "horizontal"}
                    </span>
                    <span className="text-neutral-500">
                      Do início: {d.posicaoMm.toFixed(1)} mm · até a borda:{" "}
                      {distEnd.toFixed(1)} mm
                    </span>
                    <input
                      type="number"
                      min={0}
                      step={0.1}
                      value={d.posicaoMm}
                      onChange={(e) =>
                        updateDobraPos(d.id, Number(e.target.value) || 0)
                      }
                      className="rounded-lg border border-sagra-border bg-white px-2 py-1.5 text-sm tabular-nums"
                    />
                  </label>
                );
              })}
          </div>
          <p className="text-[11px] text-neutral-500">
            Área útil {usable.w.toFixed(1)} × {usable.h.toFixed(1)} mm.
          </p>
        </section>

        <section className="space-y-3 rounded-2xl border border-sagra-border bg-white p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-neutral-800">
            Sentido e sequência de fechamento
          </h3>
          <p className="text-xs text-neutral-500">
            Ordem 1 = fecha primeiro. No mockup, o desdobramento inverte essa
            ordem.
          </p>
          <ul className="space-y-2">
            {[...folheto.dobras]
              .sort((a, b) => a.ordem - b.ordem)
              .map((d, i) => (
                <li
                  key={d.id}
                  className="flex flex-wrap items-center gap-2 rounded-xl border border-sagra-border bg-slate-50 px-3 py-2"
                >
                  <span
                    className="flex size-7 items-center justify-center rounded-full text-xs font-bold text-white"
                    style={{
                      background:
                        FOLD_LINE_COLORS[i % FOLD_LINE_COLORS.length],
                    }}
                  >
                    {d.ordem}
                  </span>
                  <span className="text-sm text-neutral-800">
                    {d.eixo === "vertical" ? "Vertical" : "Horizontal"} @{" "}
                    {d.posicaoMm.toFixed(1)} mm
                  </span>
                  <select
                    value={d.sentido}
                    onChange={(e) =>
                      updateSentido(d.id, e.target.value as FoldSentido)
                    }
                    className="rounded-lg border border-sagra-border bg-white px-2 py-1 text-xs"
                  >
                    <option value="valley">Valley (para dentro)</option>
                    <option value="mountain">Mountain (para fora)</option>
                  </select>
                  <div className="ml-auto flex gap-1">
                    <button
                      type="button"
                      aria-label="Subir na ordem"
                      onClick={() => moveOrdem(d.id, -1)}
                      className="rounded border border-sagra-border bg-white p-1 text-neutral-600 hover:bg-neutral-100"
                    >
                      <ArrowUp className="size-3.5" />
                    </button>
                    <button
                      type="button"
                      aria-label="Descer na ordem"
                      onClick={() => moveOrdem(d.id, 1)}
                      className="rounded border border-sagra-border bg-white p-1 text-neutral-600 hover:bg-neutral-100"
                    >
                      <ArrowDown className="size-3.5" />
                    </button>
                  </div>
                </li>
              ))}
          </ul>
          <FoldStackPreview dobras={folheto.dobras} />
        </section>

        <section className="space-y-3 rounded-2xl border border-sagra-border bg-white p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-neutral-800">
            Sequência de páginas
          </h3>
          <p className="text-xs text-neutral-500">
            Número de leitura de cada painel (L→R). Padrão: frente 1…N; verso
            tipográfico {panelCount * 2}…{panelCount + 1}. Não remapeia a arte do
            PDF — só identifica a página.
          </p>
          <div className="overflow-x-auto">
            <div
              className="inline-grid min-w-full gap-2"
              style={{
                gridTemplateColumns: `auto repeat(${panelCount}, minmax(3.5rem, 1fr))`,
              }}
            >
              <span className="self-center text-[11px] font-medium uppercase tracking-wide text-neutral-500">
                Frente
              </span>
              {sequencia.frente.map((num, i) => (
                <label key={`f-${i}`} className="flex flex-col gap-1">
                  <span className="text-center text-[10px] text-neutral-500">
                    P{i + 1}
                  </span>
                  <input
                    type="number"
                    min={1}
                    step={1}
                    value={num}
                    onChange={(e) =>
                      updateSeqSlot("frente", i, Number(e.target.value))
                    }
                    className={`rounded-lg border bg-white px-2 py-1.5 text-center text-sm tabular-nums ${
                      seqDupes.has(num)
                        ? "border-amber-400"
                        : "border-sagra-border"
                    }`}
                  />
                </label>
              ))}
              {hasVerso && sequencia.verso && (
                <>
                  <span className="self-center text-[11px] font-medium uppercase tracking-wide text-neutral-500">
                    Verso
                  </span>
                  {sequencia.verso.map((num, i) => (
                    <label key={`v-${i}`} className="flex flex-col gap-1">
                      <span className="text-center text-[10px] text-neutral-500">
                        P{i + 1}
                      </span>
                      <input
                        type="number"
                        min={1}
                        step={1}
                        value={num}
                        onChange={(e) =>
                          updateSeqSlot("verso", i, Number(e.target.value))
                        }
                        className={`rounded-lg border bg-white px-2 py-1.5 text-center text-sm tabular-nums ${
                          seqDupes.has(num)
                            ? "border-amber-400"
                            : "border-sagra-border"
                        }`}
                      />
                    </label>
                  ))}
                </>
              )}
            </div>
          </div>
          {seqDupes.size > 0 && (
            <p className="text-[11px] text-amber-700">
              Há números repetidos ({[...seqDupes].join(", ")}). Isso é permitido,
              mas confira se a sequência está correta.
            </p>
          )}
          <div className="flex flex-wrap gap-1 text-xs text-neutral-600">
            {sequencia.frente.map((n, i) => (
              <span
                key={`pf-${i}`}
                className="rounded border border-sagra-border bg-slate-50 px-2 py-1 tabular-nums"
              >
                F{i + 1}→{n}
              </span>
            ))}
            {sequencia.verso?.map((n, i) => (
              <span
                key={`pv-${i}`}
                className="rounded border border-sagra-border bg-slate-100 px-2 py-1 tabular-nums"
              >
                V{i + 1}→{n}
              </span>
            ))}
          </div>
        </section>
      </div>

      <div className="sticky bottom-0 z-10 flex items-center justify-between gap-2 border-t border-sagra-border bg-slate-50/95 py-3 backdrop-blur">
        <button
          type="button"
          onClick={onBack}
          disabled={saving}
          className="inline-flex items-center gap-1.5 rounded-lg border border-sagra-border bg-white px-4 py-2 text-sm text-neutral-700 shadow-sm hover:bg-neutral-100 disabled:opacity-40"
        >
          <ArrowLeft className="size-4" aria-hidden />
          Voltar
        </button>
        <button
          type="button"
          disabled={saving}
          onClick={() => onConfirm(cropJson)}
          className="inline-flex items-center gap-2 rounded-lg bg-primary-green px-5 py-2 text-sm font-semibold text-white shadow-sm transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {saving && <Loader2 className="size-4 animate-spin" aria-hidden />}
          Gerar Prova WEB
        </button>
      </div>
    </div>
  );
}

function FoldStackPreview({ dobras }: { dobras: FoldDobra[] }) {
  const sorted = [...dobras].sort((a, b) => a.ordem - b.ordem);
  return (
    <div className="rounded-xl border border-dashed border-sagra-border bg-white px-4 py-3">
      <p className="text-[11px] font-medium uppercase tracking-wide text-neutral-500">
        Esquema de fechamento
      </p>
      <div className="mt-2 flex flex-wrap items-center gap-1 text-xs text-neutral-700">
        <span className="rounded bg-slate-100 px-2 py-1">Folha aberta</span>
        {sorted.map((d, i) => (
          <span key={d.id} className="inline-flex items-center gap-1">
            <span aria-hidden>→</span>
            <span
              className="rounded px-2 py-1 font-medium text-white"
              style={{
                background: FOLD_LINE_COLORS[i % FOLD_LINE_COLORS.length],
              }}
            >
              fecha #{d.ordem} ({d.sentido === "valley" ? "V" : "M"})
            </span>
          </span>
        ))}
        <span aria-hidden>→</span>
        <span className="rounded bg-slate-800 px-2 py-1 text-white">
          Embalado
        </span>
      </div>
    </div>
  );
}

function PresetDiagram({ preset }: { preset: FoldPresetId }) {
  const w = 72;
  const h = 48;
  const cuts = dobrasFromPreset(preset, w, h);
  return (
    <svg
      viewBox={`0 0 ${w} ${h}`}
      className="h-12 w-full max-w-[96px]"
      aria-hidden
    >
      <rect
        x={1}
        y={1}
        width={w - 2}
        height={h - 2}
        rx={2}
        fill="#f8fafc"
        stroke="#94a3b8"
        strokeWidth={1}
      />
      {cuts.map((d, i) => {
        const color = FOLD_LINE_COLORS[i % FOLD_LINE_COLORS.length];
        if (d.eixo === "vertical") {
          return (
            <line
              key={d.id}
              x1={d.posicaoMm}
              y1={2}
              x2={d.posicaoMm}
              y2={h - 2}
              stroke={color}
              strokeWidth={1.5}
              strokeDasharray="3 2"
            />
          );
        }
        return (
          <line
            key={d.id}
            x1={2}
            y1={d.posicaoMm}
            x2={w - 2}
            y2={d.posicaoMm}
            stroke={color}
            strokeWidth={1.5}
            strokeDasharray="3 2"
          />
        );
      })}
    </svg>
  );
}
