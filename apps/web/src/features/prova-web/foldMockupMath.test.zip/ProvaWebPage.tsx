import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  BookOpen,
  Check,
  Copy,
  FolderOpen,
  Loader2,
  RefreshCw,
} from "lucide-react";
import { useEffect, useState } from "react";

import type { ProofPreviewPagesData } from "@/api/proof-portal";
import {
  fetchProvaWebInfo,
  fetchProvaWebManifest,
  provaWebPageUrl,
  type ProvaWebManifest,
} from "@/api/provaWeb";
import { ClienteProofMockupPanel } from "@/features/cliente/components/proof/ClienteProofMockupPanel";
import logoUrl from "@/logo.png";

import { ProvaWebFilePicker } from "./ProvaWebFilePicker";
import { ProvaWebViewerShell } from "./ProvaWebViewerShell";

interface ProvaWebPageProps {
  ano: number;
  osId: number;
}

export function ProvaWebPage({ ano, osId }: ProvaWebPageProps) {
  const queryClient = useQueryClient();
  const [pickerOpen, setPickerOpen] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);

  const infoQuery = useQuery({
    queryKey: ["prova-web-info", ano, osId],
    queryFn: () => fetchProvaWebInfo(ano, osId),
    retry: 1,
  });

  const info = infoQuery.data;
  const hasRecord = Boolean(info?.record);
  const showPicker = pickerOpen || (Boolean(info) && !hasRecord);
  const portalUrl = info?.portalUrl?.trim() || "";

  const manifestQuery = useQuery({
    queryKey: ["prova-web-manifest", ano, osId],
    queryFn: () => fetchProvaWebManifest(ano, osId),
    enabled: hasRecord && !showPicker,
    retry: 1,
    staleTime: 60_000,
  });

  useEffect(() => {
    document.title = `Prova WEB — OS ${osId}/${ano}`;
  }, [ano, osId]);

  const handleSaved = () => {
    setPickerOpen(false);
    void queryClient.invalidateQueries({ queryKey: ["prova-web-info", ano, osId] });
    void queryClient.invalidateQueries({
      queryKey: ["prova-web-manifest", ano, osId],
    });
  };

  const handleCopyLink = async () => {
    if (!portalUrl) return;
    try {
      await navigator.clipboard.writeText(portalUrl);
      setLinkCopied(true);
      window.setTimeout(() => setLinkCopied(false), 1500);
    } catch {
      window.alert("Não foi possível copiar o link.");
    }
  };

  return (
    <div className="flex min-h-dvh flex-col bg-sagra-bg text-sagra-text">
      <header className="flex h-14 shrink-0 items-center gap-3 bg-secondary-blue px-3 text-white shadow-md sm:h-16 sm:px-4">
        <img
          src={logoUrl}
          alt="DEAPA"
          className="h-8 w-auto shrink-0 object-contain sm:h-10"
        />
        <BookOpen className="hidden size-5 shrink-0 text-primary-green sm:block" aria-hidden />
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-sm font-semibold tracking-wide sm:text-base">
            Prova WEB — OS {osId}/{ano}
            {info?.record?.versao != null
              ? ` · Prova ${info.record.versao}`
              : ""}
          </h1>
          {info && (info.titulo || info.produto) && (
            <p className="truncate text-xs text-white/70">
              {[info.titulo, info.produto].filter(Boolean).join(" · ")}
            </p>
          )}
        </div>
        {hasRecord && !showPicker && (
          <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
            {portalUrl ? (
              <button
                type="button"
                onClick={() => void handleCopyLink()}
                className="flex items-center gap-1.5 rounded-md border border-white/30 px-2 py-1.5 text-sm font-medium hover:bg-white/10 sm:px-3"
                title={portalUrl}
              >
                {linkCopied ? (
                  <Check className="size-4 shrink-0 text-primary-green" aria-hidden />
                ) : (
                  <Copy className="size-4 shrink-0" aria-hidden />
                )}
                <span className="hidden sm:inline">
                  {linkCopied ? "Copiado" : "Copiar link do cliente"}
                </span>
              </button>
            ) : null}
            <button
              type="button"
              onClick={() => setPickerOpen(true)}
              className="flex items-center gap-1.5 rounded-md border border-white/30 px-2 py-1.5 text-sm font-medium hover:bg-white/10 sm:gap-2 sm:px-3"
            >
              <FolderOpen className="size-4 shrink-0" aria-hidden />
              <span className="hidden sm:inline">Trocar arquivo</span>
            </button>
          </div>
        )}
      </header>

      <main className="flex min-h-0 flex-1 flex-col">
        {infoQuery.isLoading && (
          <CenteredState>
            <Loader2
              className="size-8 animate-spin text-primary-green"
              aria-hidden
            />
            <p className="text-sm text-neutral-600">Carregando dados da OS…</p>
          </CenteredState>
        )}

        {infoQuery.isError && (
          <CenteredState>
            <p className="text-sm font-medium text-sagra-danger">
              {infoQuery.error instanceof Error
                ? infoQuery.error.message
                : "Erro ao carregar a OS."}
            </p>
            <RetryButton onClick={() => void infoQuery.refetch()} />
          </CenteredState>
        )}

        {info && showPicker && (
          <ProvaWebFilePicker
            ano={ano}
            osId={osId}
            info={info}
            onSaved={handleSaved}
            onViewExisting={() => setPickerOpen(false)}
            onCancel={hasRecord ? () => setPickerOpen(false) : undefined}
          />
        )}

        {info && !showPicker && hasRecord && (
          <>
            {manifestQuery.isLoading && (
              <CenteredState>
                <Loader2
                  className="size-8 animate-spin text-primary-green"
                  aria-hidden
                />
                <p className="text-sm text-neutral-600">
                  Renderizando as páginas da prova…
                </p>
                <p className="text-xs text-neutral-500">
                  A primeira abertura pode demorar alguns segundos.
                </p>
              </CenteredState>
            )}

            {manifestQuery.isError && (
              <CenteredState>
                <p className="max-w-md text-center text-sm font-medium text-sagra-danger">
                  {manifestQuery.error instanceof Error
                    ? manifestQuery.error.message
                    : "Erro ao renderizar a prova."}
                </p>
                <div className="flex gap-2">
                  <RetryButton onClick={() => void manifestQuery.refetch()} />
                  <button
                    type="button"
                    onClick={() => setPickerOpen(true)}
                    className="rounded-lg border border-sagra-border bg-white px-3 py-1.5 text-xs text-neutral-700 shadow-sm hover:bg-neutral-50"
                  >
                    Escolher outro arquivo
                  </button>
                </div>
              </CenteredState>
            )}

            {manifestQuery.data &&
              (info.isPapelaria ? (
                <PapelariaMockupStage
                  ano={ano}
                  osId={osId}
                  manifest={manifestQuery.data}
                  produtoFallback={info.produto}
                />
              ) : (
                <ProvaWebViewerShell
                  ano={ano}
                  osId={osId}
                  manifest={manifestQuery.data}
                />
              ))}
          </>
        )}
      </main>
    </div>
  );
}

function PapelariaMockupStage({
  ano,
  osId,
  manifest,
  produtoFallback,
}: {
  ano: number;
  osId: number;
  manifest: ProvaWebManifest;
  produtoFallback?: string;
}) {
  const previewData: ProofPreviewPagesData = {
    isPapelaria: true,
    pages: manifest.pages.map((p) => ({
      page: p.page,
      url: provaWebPageUrl(ano, osId, p.page, manifest.cacheKey),
    })),
    total_pages: manifest.pageCount,
    truncated: manifest.truncated,
    mockupConfigJson: manifest.mockupConfigJson,
    produto: manifest.produto,
    arquivoModelo: manifest.arquivoModelo,
    frenteVerso: manifest.frenteVerso,
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col p-4">
      <ClienteProofMockupPanel
        previewData={previewData}
        isLoading={false}
        isError={false}
        produtoFallback={produtoFallback}
        fillHeight
        className="flex-1"
      />
    </div>
  );
}

function CenteredState({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-3 p-8">
      {children}
    </div>
  );
}

function RetryButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex items-center gap-1.5 rounded-lg border border-sagra-border bg-white px-3 py-1.5 text-xs font-medium text-neutral-700 shadow-sm hover:bg-neutral-50"
    >
      <RefreshCw className="size-3.5" aria-hidden />
      Tentar novamente
    </button>
  );
}
