import { BookOpen, Box } from "lucide-react";
import { useCallback, useState } from "react";

import {
  provaWebPageUrl,
  resolveProvaWebSpineUrl,
  type ProvaWebManifestBase,
  type ProvaWebPageMeta,
} from "@/api/provaWeb";

import { ProvaWebBookMockup3D } from "./ProvaWebBookMockup3D";
import { ProvaWebFlipbook } from "./ProvaWebFlipbook";
import { ProvaWebFoldMockup3D } from "./ProvaWebFoldMockup3D";

type ViewerTab = "folhear" | "mockup";

export interface ProvaWebViewerShellProps {
  ano: number;
  osId: number;
  manifest: ProvaWebManifestBase;
  /** Sobrescreve URL das páginas (portal do cliente). */
  buildPageUrl?: (page: number) => string;
  /** URL explícita do spine (portal). Se omitida, resolve do bookMockup. */
  spineUrl?: string | null;
}

/**
 * Abas Folhear / Mockup 3D.
 * - foldMockup → Mockup 3D default; Folhear opcional (1–2 págs)
 * - bookMockup.lombadaMm > 0 → Folhear | Mockup livro
 * - senão → só Folhear
 */
export function ProvaWebViewerShell({
  ano,
  osId,
  manifest,
  buildPageUrl,
  spineUrl: spineUrlProp,
}: ProvaWebViewerShellProps) {
  const foldMockup = manifest.foldMockup;
  const bookMockup = manifest.bookMockup;
  const isFold = Boolean(foldMockup?.panels?.length);
  const isBook =
    !isFold && Boolean(bookMockup) && (bookMockup?.lombadaMm ?? 0) > 0;
  const showMockupTab = isFold || isBook;

  const [tab, setTab] = useState<ViewerTab>(isFold ? "mockup" : "folhear");

  const resolvedPageUrl = useCallback(
    (page: ProvaWebPageMeta) =>
      buildPageUrl
        ? buildPageUrl(page.page)
        : provaWebPageUrl(ano, osId, page.page, manifest.cacheKey),
    [ano, buildPageUrl, manifest.cacheKey, osId],
  );

  const spineUrl =
    spineUrlProp !== undefined
      ? spineUrlProp
      : resolveProvaWebSpineUrl(bookMockup, {
          ano,
          osId,
          cacheKey: manifest.cacheKey,
        });

  if (!showMockupTab) {
    return (
      <ProvaWebFlipbook
        ano={ano}
        osId={osId}
        manifest={manifest}
        buildPageUrl={buildPageUrl}
      />
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex shrink-0 items-center justify-center gap-1 border-b border-sagra-border bg-white px-3 py-2">
        {isFold ? (
          <>
            <TabButton
              active={tab === "mockup"}
              onClick={() => setTab("mockup")}
              icon={<Box className="size-3.5" aria-hidden />}
              label="Mockup 3D"
            />
            <TabButton
              active={tab === "folhear"}
              onClick={() => setTab("folhear")}
              icon={<BookOpen className="size-3.5" aria-hidden />}
              label="Folhear"
            />
          </>
        ) : (
          <>
            <TabButton
              active={tab === "folhear"}
              onClick={() => setTab("folhear")}
              icon={<BookOpen className="size-3.5" aria-hidden />}
              label="Folhear"
            />
            <TabButton
              active={tab === "mockup"}
              onClick={() => setTab("mockup")}
              icon={<Box className="size-3.5" aria-hidden />}
              label="Mockup 3D"
            />
          </>
        )}
      </div>

      {tab === "folhear" ? (
        <ProvaWebFlipbook
          ano={ano}
          osId={osId}
          manifest={manifest}
          buildPageUrl={buildPageUrl}
        />
      ) : isFold && foldMockup ? (
        <ProvaWebFoldMockup3D
          pages={manifest.pages}
          foldMockup={foldMockup}
          pageUrl={resolvedPageUrl}
        />
      ) : (
        bookMockup && (
          <ProvaWebBookMockup3D
            pages={manifest.pages}
            bookMockup={bookMockup}
            pageUrl={resolvedPageUrl}
            spineUrl={spineUrl}
          />
        )
      )}
    </div>
  );
}

function TabButton({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition ${
        active
          ? "bg-primary-green text-white shadow-sm"
          : "bg-slate-100 text-neutral-600 hover:bg-slate-200"
      }`}
    >
      {icon}
      {label}
    </button>
  );
}
