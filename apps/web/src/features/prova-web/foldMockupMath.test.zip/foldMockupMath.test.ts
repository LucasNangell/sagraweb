import { describe, expect, it } from "vitest";

import {
  closedAngleRad,
  defaultSequenciaPaginas,
  effectiveClosedDeg,
  normalizeSequenciaPaginas,
  unfoldLevelProgress,
} from "./foldMockupMath";

describe("foldMockupMath", () => {
  it("abre níveis na ordem inversa (0 fechado → 1 aberto)", () => {
    expect(unfoldLevelProgress(0, 2, 0)).toBe(0);
    expect(unfoldLevelProgress(0.5, 2, 0)).toBe(1);
    expect(unfoldLevelProgress(0.5, 2, 1)).toBe(0);
    expect(unfoldLevelProgress(1, 2, 1)).toBe(1);
  });

  it("interpola ângulo fechado → 0", () => {
    const closed = closedAngleRad(170, 1, 0);
    expect(closed).toBeCloseTo((170 * Math.PI) / 180, 5);
    expect(closedAngleRad(170, 1, 1)).toBeCloseTo(0, 5);
    expect(closedAngleRad(170, -1, 0)).toBeCloseTo((-170 * Math.PI) / 180, 5);
  });

  it("reduz ângulo fechado em cadeias longas", () => {
    expect(effectiveClosedDeg(170, 0, 1)).toBe(158);
    expect(effectiveClosedDeg(170, 0, 2)).toBe(158);
    expect(effectiveClosedDeg(170, 0, 3)).toBe(158);
    expect(effectiveClosedDeg(170, 1, 3)).toBe(154);
    expect(effectiveClosedDeg(170, 8, 3)).toBe(145);
  });

  it("default tipográfico frente L→R e verso 2N..N+1", () => {
    expect(defaultSequenciaPaginas(3, true)).toEqual({
      frente: [1, 2, 3],
      verso: [6, 5, 4],
    });
    expect(defaultSequenciaPaginas(2, false)).toEqual({
      frente: [1, 2],
      verso: null,
    });
  });

  it("normaliza sequência com length e fallback", () => {
    expect(
      normalizeSequenciaPaginas({ frente: [4, 6, 1], verso: [2, 3, 5] }, 3, true),
    ).toEqual({ frente: [4, 6, 1], verso: [2, 3, 5] });
    expect(normalizeSequenciaPaginas({ frente: [1] }, 3, true)).toEqual({
      frente: [1, 2, 3],
      verso: [6, 5, 4],
    });
  });
});
