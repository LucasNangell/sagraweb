/** Ângulos / progressão de desdobramento (pure — testes). */

export function unfoldLevelProgress(
  unfold01: number,
  levelCount: number,
  levelIndex: number,
): number {
  const p = Math.min(1, Math.max(0, unfold01));
  const n = Math.max(1, levelCount);
  return Math.min(1, Math.max(0, p * n - levelIndex));
}

export function closedAngleRad(
  closedDeg: number,
  sign: number,
  open01: number,
): number {
  return sign * ((closedDeg * Math.PI) / 180) * (1 - open01);
}

/**
 * Ângulo fechado seguro: máx 158°.
 * Com 2+ dobras, reduz por índice para evitar atravessar.
 */
export function effectiveClosedDeg(
  baseClosedDeg: number,
  chainIndex: number,
  hingeCount: number,
): number {
  const base = Math.min(158, baseClosedDeg);
  if (hingeCount < 2) return base;
  return Math.max(145, base - chainIndex * 4);
}

/** Default: frente 1..N; verso tipográfico 2N..N+1. */
export function defaultSequenciaPaginas(
  panelCount: number,
  hasVerso: boolean,
): { frente: number[]; verso: number[] | null } {
  const n = Math.max(1, panelCount);
  const frente = Array.from({ length: n }, (_, i) => i + 1);
  if (!hasVerso) return { frente, verso: null };
  const verso = Array.from({ length: n }, (_, i) => 2 * n - i);
  return { frente, verso };
}

export function normalizeSequenciaPaginas(
  raw: { frente?: unknown; verso?: unknown } | null | undefined,
  panelCount: number,
  hasVerso: boolean,
): { frente: number[]; verso: number[] | null } {
  const fallback = defaultSequenciaPaginas(panelCount, hasVerso);
  if (!raw || !Array.isArray(raw.frente)) return fallback;
  const frente = raw.frente.map((v, i) => {
    const n = Number(v);
    return Number.isFinite(n) && n > 0 ? Math.round(n) : fallback.frente[i]!;
  });
  while (frente.length < panelCount) {
    frente.push(frente.length + 1);
  }
  frente.length = panelCount;
  if (!hasVerso) return { frente, verso: null };
  const src =
    Array.isArray(raw.verso) && raw.verso.length > 0
      ? raw.verso
      : fallback.verso!;
  const verso = Array.from({ length: panelCount }, (_, i) => {
    const n = Number(src[i]);
    return Number.isFinite(n) && n > 0
      ? Math.round(n)
      : (fallback.verso?.[i] ?? panelCount + i + 1);
  });
  return { frente, verso };
}

export function sequenciaIsDefault(
  seq: { frente: number[]; verso: number[] | null },
  panelCount: number,
  hasVerso: boolean,
): boolean {
  const d = defaultSequenciaPaginas(panelCount, hasVerso);
  if (seq.frente.length !== d.frente.length) return false;
  if (seq.frente.some((v, i) => v !== d.frente[i])) return false;
  if (!hasVerso) return seq.verso == null;
  if (!seq.verso || !d.verso) return false;
  return seq.verso.every((v, i) => v === d.verso![i]);
}
