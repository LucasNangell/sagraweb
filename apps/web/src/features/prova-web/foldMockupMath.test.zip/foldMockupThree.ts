import * as THREE from "three";

import {
  closedAngleRad,
  effectiveClosedDeg,
  unfoldLevelProgress,
} from "./foldMockupMath";
import type {
  FoldMockupHinge,
  FoldMockupPanel,
  ProvaWebFoldMockupMeta,
} from "@/api/provaWeb";

export const CLOSED_DEG = 158;
export const STACK_THICKNESS_MM = 0.85;
export const HINGE_HIT_MM = 12;
export const DEFAULT_ROT_Y = -0.38;
export const DEFAULT_ROT_X = 0.32;
export const MAX_ROT_X = 0.95;
/** rad/px — arraste esquerda → horário (rotY + dx). */
export const ORBIT_SENS_Y = 0.01;
export const ORBIT_SENS_X = 0.008;

export type HingeRuntime = {
  key: string;
  group: THREE.Object3D;
  eixo: "vertical" | "horizontal";
  /** +1 valley / -1 mountain (sign applied to closed angle). */
  sign: number;
  ordem: number;
  /** Índice espacial na cadeia (0 = primeira dobra). */
  chainIndex: number;
  axis: "y" | "x";
  /** Painel anexado por esta dobra (Z dinâmico). */
  panelGroup: THREE.Object3D;
  /** Sinal de empilhamento Z. */
  stackSign: number;
};

export type FoldSceneHandle = {
  renderer: THREE.WebGLRenderer;
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  orbitGroup: THREE.Group;
  pivotGroup: THREE.Group;
  contentGroup: THREE.Group;
  hinges: HingeRuntime[];
  panelMeshes: THREE.Mesh[];
  raycaster: THREE.Raycaster;
  disposables: Array<{ dispose: () => void }>;
  setOrbit: (rotX: number, rotY: number) => void;
  setHingeAnglesFromUnfold: (unfold01: number) => void;
  recenterPivot: () => void;
  resize: (width: number, height: number) => void;
  render: () => void;
  dispose: () => void;
  pickHingeNear: (ndcX: number, ndcY: number) => HingeRuntime | null;
};

function hingeKey(h: Pick<FoldMockupHinge, "between" | "eixo">): string {
  return `${h.between[0]}|${h.between[1]}|${h.eixo}`;
}

function makeHingeKey(
  a: string,
  b: string,
  eixo: "vertical" | "horizontal",
): string {
  return `${a}|${b}|${eixo}`;
}

function findHinge(
  hinges: FoldMockupHinge[],
  a: string,
  b: string,
  eixo: "vertical" | "horizontal",
): FoldMockupHinge | undefined {
  return hinges.find(
    (h) =>
      h.eixo === eixo &&
      ((h.between[0] === a && h.between[1] === b) ||
        (h.between[1] === a && h.between[0] === b)),
  );
}

async function loadTexture(
  url: string | null,
): Promise<THREE.Texture | null> {
  if (!url) return null;
  try {
    const res = await fetch(url, { credentials: "include" });
    if (!res.ok) return null;
    const blob = await res.blob();
    const objUrl = URL.createObjectURL(blob);
    const texture = await new Promise<THREE.Texture>((resolve, reject) => {
      const loader = new THREE.TextureLoader();
      loader.load(
        objUrl,
        (tex) => {
          URL.revokeObjectURL(objUrl);
          tex.colorSpace = THREE.SRGBColorSpace;
          tex.needsUpdate = true;
          resolve(tex);
        },
        undefined,
        (err) => {
          URL.revokeObjectURL(objUrl);
          reject(err);
        },
      );
    });
    return texture;
  } catch {
    return null;
  }
}

function makeLabelTexture(
  pageNum: number | null,
): THREE.CanvasTexture | null {
  if (pageNum == null || pageNum <= 0) return null;
  const size = 128;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  ctx.clearRect(0, 0, size, size);
  ctx.beginPath();
  ctx.arc(size / 2, size / 2, size * 0.38, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(15, 23, 42, 0.78)";
  ctx.fill();
  ctx.fillStyle = "#ffffff";
  ctx.font = `bold ${Math.round(size * 0.42)}px system-ui,sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(String(pageNum), size / 2, size / 2 + 2);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

function panelUVs(
  panel: FoldMockupPanel,
  pageW: number,
  pageH: number,
  forBack: boolean,
): THREE.Float32BufferAttribute {
  const u0 = panel.xMm / pageW;
  const u1 = (panel.xMm + panel.wMm) / pageW;
  const vTop = 1 - panel.yMm / pageH;
  const vBot = 1 - (panel.yMm + panel.hMm) / pageH;

  if (!forBack) {
    return new THREE.Float32BufferAttribute(
      [u0, vBot, u1, vBot, u0, vTop, u1, vTop],
      2,
    );
  }
  const bu0 = 1 - (panel.xMm + panel.wMm) / pageW;
  const bu1 = 1 - panel.xMm / pageW;
  return new THREE.Float32BufferAttribute(
    [bu1, vBot, bu0, vBot, bu1, vTop, bu0, vTop],
    2,
  );
}

function basicPanelMat(
  map: THREE.Texture | null,
  fallback: number,
): THREE.MeshBasicMaterial {
  return new THREE.MeshBasicMaterial({
    map: map ?? undefined,
    color: map ? 0xffffff : fallback,
    side: THREE.FrontSide,
    toneMapped: false,
    polygonOffset: true,
    polygonOffsetFactor: 1,
    polygonOffsetUnits: 1,
  });
}

function makePanelMesh(
  panel: FoldMockupPanel,
  pageW: number,
  pageH: number,
  frontTex: THREE.Texture | null,
  backTex: THREE.Texture | null,
  thickness: number,
  pageFrente: number | null,
  pageVerso: number | null,
): {
  group: THREE.Group;
  meshes: THREE.Mesh[];
  disposables: Array<{ dispose: () => void }>;
} {
  const disposables: Array<{ dispose: () => void }> = [];
  const group = new THREE.Group();
  group.name = panel.id;

  const w = panel.wMm;
  const h = panel.hMm;
  const geo = new THREE.PlaneGeometry(w, h);
  const frontGeo = geo.clone();
  frontGeo.setAttribute("uv", panelUVs(panel, pageW, pageH, false));
  disposables.push(frontGeo);

  const frontMat = basicPanelMat(frontTex, 0xf7f4ef);
  disposables.push(frontMat);

  const front = new THREE.Mesh(frontGeo, frontMat);
  front.position.set(w / 2, -h / 2, thickness / 2);
  front.userData["panelId"] = panel.id;
  group.add(front);

  const backGeo = geo.clone();
  backGeo.setAttribute("uv", panelUVs(panel, pageW, pageH, true));
  disposables.push(backGeo);
  disposables.push(geo);

  const backMat = basicPanelMat(backTex, 0xe8e2d8);
  disposables.push(backMat);

  const back = new THREE.Mesh(backGeo, backMat);
  back.rotation.y = Math.PI;
  back.position.set(w / 2, -h / 2, -thickness / 2);
  back.userData["panelId"] = panel.id;
  group.add(back);

  const labelSize = Math.min(w, h) * 0.18;
  const addBadge = (
    num: number | null,
    z: number,
    flipY: boolean,
  ) => {
    const tex = makeLabelTexture(num);
    if (!tex) return;
    disposables.push(tex);
    const lg = new THREE.PlaneGeometry(labelSize, labelSize);
    disposables.push(lg);
    const lm = new THREE.MeshBasicMaterial({
      map: tex,
      transparent: true,
      depthWrite: false,
      toneMapped: false,
      side: THREE.DoubleSide,
    });
    disposables.push(lm);
    const badge = new THREE.Mesh(lg, lm);
    const margin = labelSize * 0.55;
    badge.position.set(margin, -margin, z);
    if (flipY) badge.rotation.y = Math.PI;
    group.add(badge);
  };
  addBadge(pageFrente, thickness / 2 + 0.02, false);
  addBadge(pageVerso, -(thickness / 2 + 0.02), true);

  return { group, meshes: [front, back], disposables };
}

type BuildResult = {
  root: THREE.Group;
  hingeRuntimes: HingeRuntime[];
  meshes: THREE.Mesh[];
  disposables: Array<{ dispose: () => void }>;
};

function pageNumsForPanel(
  foldMockup: ProvaWebFoldMockupMeta,
  panelIndex: number,
): { frente: number | null; verso: number | null } {
  const pp = foldMockup.panelPages;
  return {
    frente: pp?.frente[panelIndex] ?? panelIndex + 1,
    verso: foldMockup.hasVerso
      ? (pp?.verso?.[panelIndex] ?? null)
      : null,
  };
}

/** Tríptico C-fold: 3 painéis 1D e ambas as dobras valley. */
function isCFold1D(
  panels: FoldMockupPanel[],
  hinges: FoldMockupHinge[],
  axis: "vertical" | "horizontal",
): boolean {
  if (panels.length !== 3) return false;
  const axisHinges = hinges.filter((h) => h.eixo === axis);
  if (axisHinges.length !== 2) return false;
  return axisHinges.every((h) => h.sentido === "valley");
}

function buildCFold(
  panels: FoldMockupPanel[],
  hinges: FoldMockupHinge[],
  axis: "vertical" | "horizontal",
  pageW: number,
  pageH: number,
  frontTex: THREE.Texture | null,
  backTex: THREE.Texture | null,
  thickness: number,
  foldMockup: ProvaWebFoldMockupMeta,
): BuildResult {
  const ordered =
    axis === "vertical"
      ? [...panels].sort((a, b) => a.xMm - b.xMm || a.yMm - b.yMm)
      : [...panels].sort((a, b) => a.yMm - b.yMm || a.xMm - b.xMm);

  const left = ordered[0]!;
  const center = ordered[1]!;
  const right = ordered[2]!;
  const hingeRuntimes: HingeRuntime[] = [];
  const meshes: THREE.Mesh[] = [];
  const disposables: Array<{ dispose: () => void }> = [];

  const mk = (panel: FoldMockupPanel, index: number) => {
    const nums = pageNumsForPanel(foldMockup, index);
    const b = makePanelMesh(
      panel,
      pageW,
      pageH,
      frontTex,
      backTex,
      thickness,
      nums.frente,
      nums.verso,
    );
    disposables.push(...b.disposables);
    meshes.push(...b.meshes);
    return b.group;
  };

  // Centro ancorado em (0,0); left/right dobram sobre ele.
  const root = new THREE.Group();
  const gCenter = mk(center, 1);
  gCenter.position.set(0, 0, 0);
  root.add(gCenter);

  const hLeft =
    findHinge(hinges, left.id, center.id, axis) ??
    ({
      between: [left.id, center.id],
      eixo: axis,
      sentido: "valley",
      ordem: 1,
    } as FoldMockupHinge);
  const hRight =
    findHinge(hinges, center.id, right.id, axis) ??
    ({
      between: [center.id, right.id],
      eixo: axis,
      sentido: "valley",
      ordem: 2,
    } as FoldMockupHinge);

  // Esquerda: hinge na borda esquerda do centro; painel ocupa [-w, 0]
  const hingeL = new THREE.Group();
  hingeL.name = `hinge-${hLeft.between.join("-")}`;
  if (axis === "vertical") {
    hingeL.position.set(0, 0, 0);
  } else {
    hingeL.position.set(0, 0, 0);
  }
  root.add(hingeL);
  const gLeft = mk(left, 0);
  if (axis === "vertical") {
    gLeft.position.set(-left.wMm, 0, 0);
  } else {
    gLeft.position.set(0, left.hMm, 0);
  }
  hingeL.add(gLeft);
  // Valley: esquerda gira para cima do centro (+Y rot / -X rot)
  const signL = 1;
  hingeRuntimes.push({
    key: hingeKey(hLeft),
    group: hingeL,
    eixo: axis,
    sign: signL,
    ordem: hLeft.ordem,
    chainIndex: 0,
    axis: axis === "vertical" ? "y" : "x",
    panelGroup: gLeft,
    stackSign: 1,
  });

  // Direita: hinge na borda direita do centro
  const hingeR = new THREE.Group();
  hingeR.name = `hinge-${hRight.between.join("-")}`;
  if (axis === "vertical") {
    hingeR.position.set(center.wMm, 0, 0);
  } else {
    hingeR.position.set(0, -center.hMm, 0);
  }
  root.add(hingeR);
  const gRight = mk(right, 2);
  gRight.position.set(0, 0, 0);
  hingeR.add(gRight);
  const signR = -1;
  hingeRuntimes.push({
    key: hingeKey(hRight),
    group: hingeR,
    eixo: axis,
    sign: signR,
    ordem: hRight.ordem,
    chainIndex: 1,
    axis: axis === "vertical" ? "y" : "x",
    panelGroup: gRight,
    stackSign: 1,
  });

  return { root, hingeRuntimes, meshes, disposables };
}

function buildAccordion(
  panels: FoldMockupPanel[],
  hinges: FoldMockupHinge[],
  axis: "vertical" | "horizontal",
  pageW: number,
  pageH: number,
  frontTex: THREE.Texture | null,
  backTex: THREE.Texture | null,
  thickness: number,
  foldMockup: ProvaWebFoldMockupMeta,
): BuildResult {
  const ordered =
    axis === "vertical"
      ? [...panels].sort((a, b) => a.xMm - b.xMm || a.yMm - b.yMm)
      : [...panels].sort((a, b) => a.yMm - b.yMm || a.xMm - b.xMm);

  const hingeRuntimes: HingeRuntime[] = [];
  const meshes: THREE.Mesh[] = [];
  const disposables: Array<{ dispose: () => void }> = [];

  const root = new THREE.Group();
  let parent: THREE.Object3D = root;

  ordered.forEach((panel, index) => {
    const nums = pageNumsForPanel(foldMockup, index);
    const built = makePanelMesh(
      panel,
      pageW,
      pageH,
      frontTex,
      backTex,
      thickness,
      nums.frente,
      nums.verso,
    );
    disposables.push(...built.disposables);
    meshes.push(...built.meshes);

    if (index === 0) {
      built.group.position.z = 0;
      parent.add(built.group);
    } else {
      const prev = ordered[index - 1]!;
      const hDef =
        findHinge(hinges, prev.id, panel.id, axis) ??
        ({
          between: [prev.id, panel.id],
          eixo: axis,
          sentido: "valley",
          ordem: index,
        } as FoldMockupHinge);

      const sign = hDef.sentido === "mountain" ? -1 : 1;
      // Z dinâmico inicial (fechado); atualizado em setHingeAnglesFromUnfold
      built.group.position.z = sign * thickness * index;

      const hingeGroup = new THREE.Group();
      hingeGroup.name = `hinge-${hDef.between.join("-")}`;
      if (axis === "vertical") {
        hingeGroup.position.set(prev.wMm, 0, 0);
      } else {
        hingeGroup.position.set(0, -prev.hMm, 0);
      }
      parent.add(hingeGroup);
      hingeGroup.add(built.group);

      hingeRuntimes.push({
        key: hingeKey(hDef),
        group: hingeGroup,
        eixo: axis,
        sign,
        ordem: hDef.ordem,
        chainIndex: index - 1,
        axis: axis === "vertical" ? "y" : "x",
        panelGroup: built.group,
        stackSign: sign,
      });
      parent = hingeGroup;
    }
  });

  return { root, hingeRuntimes, meshes, disposables };
}

function buildCrossFold(
  panels: FoldMockupPanel[],
  hinges: FoldMockupHinge[],
  pageW: number,
  pageH: number,
  frontTex: THREE.Texture | null,
  backTex: THREE.Texture | null,
  thickness: number,
  foldMockup: ProvaWebFoldMockupMeta,
): BuildResult | null {
  const tl =
    panels.find((p) => p.id === "p0_0") ??
    [...panels].sort((a, b) => a.yMm - b.yMm || a.xMm - b.xMm)[0];
  if (!tl) return null;
  const tr =
    panels.find((p) => Math.abs(p.yMm - tl.yMm) < 0.5 && p.xMm > tl.xMm) ??
    null;
  const bl =
    panels.find((p) => Math.abs(p.xMm - tl.xMm) < 0.5 && p.yMm > tl.yMm) ??
    null;
  const br =
    tr && bl
      ? panels.find(
          (p) =>
            Math.abs(p.xMm - tr.xMm) < 0.5 && Math.abs(p.yMm - bl.yMm) < 0.5,
        ) ?? null
      : null;
  if (!tr || !bl || !br) return null;

  const hingeRuntimes: HingeRuntime[] = [];
  const meshes: THREE.Mesh[] = [];
  const disposables: Array<{ dispose: () => void }> = [];
  const indexOf = (p: FoldMockupPanel) =>
    panels.findIndex((x) => x.id === p.id);

  const mk = (panel: FoldMockupPanel) => {
    const nums = pageNumsForPanel(foldMockup, Math.max(0, indexOf(panel)));
    const b = makePanelMesh(
      panel,
      pageW,
      pageH,
      frontTex,
      backTex,
      thickness,
      nums.frente,
      nums.verso,
    );
    disposables.push(...b.disposables);
    meshes.push(...b.meshes);
    return b.group;
  };

  const root = new THREE.Group();
  const gTl = mk(tl);
  gTl.position.z = 0;
  root.add(gTl);

  const hH = findHinge(hinges, tl.id, bl.id, "horizontal");
  const signH = (hH?.sentido ?? "valley") === "mountain" ? -1 : 1;
  const hingeH = new THREE.Group();
  hingeH.position.set(0, -tl.hMm, 0);
  root.add(hingeH);
  const gBl = mk(bl);
  gBl.position.z = signH * thickness;
  hingeH.add(gBl);
  hingeRuntimes.push({
    key: makeHingeKey(tl.id, bl.id, "horizontal"),
    group: hingeH,
    eixo: "horizontal",
    sign: signH,
    ordem: hH?.ordem ?? 2,
    chainIndex: 1,
    axis: "x",
    panelGroup: gBl,
    stackSign: signH,
  });

  const hV = findHinge(hinges, tl.id, tr.id, "vertical");
  const signV = (hV?.sentido ?? "valley") === "mountain" ? -1 : 1;
  const hingeV = new THREE.Group();
  hingeV.position.set(tl.wMm, 0, 0);
  root.add(hingeV);
  const gTr = mk(tr);
  gTr.position.z = signV * thickness;
  hingeV.add(gTr);

  const hingeVH = new THREE.Group();
  hingeVH.position.set(0, -tr.hMm, 0);
  hingeV.add(hingeVH);
  const gBr = mk(br);
  gBr.position.z = signV * thickness * 2;
  hingeVH.add(gBr);

  hingeRuntimes.push({
    key: makeHingeKey(tl.id, tr.id, "vertical"),
    group: hingeV,
    eixo: "vertical",
    sign: signV,
    ordem: hV?.ordem ?? 1,
    chainIndex: 0,
    axis: "y",
    panelGroup: gTr,
    stackSign: signV,
  });

  const hHR = findHinge(hinges, tr.id, br.id, "horizontal");
  const signHR =
    (hHR?.sentido ?? hH?.sentido ?? "valley") === "mountain" ? -1 : 1;
  hingeRuntimes.push({
    key: makeHingeKey(tr.id, br.id, "horizontal"),
    group: hingeVH,
    eixo: "horizontal",
    sign: signHR,
    ordem: hHR?.ordem ?? hH?.ordem ?? 2,
    chainIndex: 1,
    axis: "x",
    panelGroup: gBr,
    stackSign: signV,
  });

  return { root, hingeRuntimes, meshes, disposables };
}

export async function createFoldScene(
  canvas: HTMLCanvasElement,
  foldMockup: ProvaWebFoldMockupMeta,
  frontUrl: string | null,
  backUrl: string | null,
): Promise<FoldSceneHandle> {
  const pageW = Math.max(10, foldMockup.pageWidthMm);
  const pageH = Math.max(10, foldMockup.pageHeightMm);
  const thickness = STACK_THICKNESS_MM;

  const [frontTex, backTex] = await Promise.all([
    loadTexture(frontUrl),
    foldMockup.hasVerso ? loadTexture(backUrl) : Promise.resolve(null),
  ]);

  const disposables: Array<{ dispose: () => void }> = [];
  if (frontTex) disposables.push(frontTex);
  if (backTex) disposables.push(backTex);

  const hasV = foldMockup.hinges.some((h) => h.eixo === "vertical");
  const hasH = foldMockup.hinges.some((h) => h.eixo === "horizontal");
  const cross = hasV && hasH;
  const axis: "vertical" | "horizontal" =
    hasH && !hasV ? "horizontal" : "vertical";

  let built: BuildResult | null =
    cross
      ? buildCrossFold(
          foldMockup.panels,
          foldMockup.hinges,
          pageW,
          pageH,
          frontTex,
          backTex,
          thickness,
          foldMockup,
        )
      : null;
  if (!built) {
    if (isCFold1D(foldMockup.panels, foldMockup.hinges, axis)) {
      built = buildCFold(
        foldMockup.panels,
        foldMockup.hinges,
        axis,
        pageW,
        pageH,
        frontTex,
        backTex,
        thickness,
        foldMockup,
      );
    } else {
      built = buildAccordion(
        foldMockup.panels,
        foldMockup.hinges,
        axis,
        pageW,
        pageH,
        frontTex,
        backTex,
        thickness,
        foldMockup,
      );
    }
  }
  disposables.push(...built.disposables);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xc5d0dc);

  const camera = new THREE.PerspectiveCamera(42, 1, 1, 5000);
  const maxDim = Math.max(pageW, pageH);
  camera.position.set(0, 0, maxDim * 2.2);

  const orbitGroup = new THREE.Group();
  const pivotGroup = new THREE.Group();
  const contentGroup = new THREE.Group();
  contentGroup.add(built.root);
  pivotGroup.add(contentGroup);
  orbitGroup.add(pivotGroup);
  scene.add(orbitGroup);

  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: false,
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.NoToneMapping;

  const raycaster = new THREE.Raycaster();
  const box = new THREE.Box3();
  const center = new THREE.Vector3();

  const hinges = built.hingeRuntimes;
  const hingeCount = Math.max(1, hinges.length);

  const setHingeAnglesFromUnfold = (unfold01: number) => {
    const levels = [...new Set(hinges.map((h) => h.ordem))].sort(
      (a, b) => b - a,
    );
    const n = Math.max(1, levels.length);
    const openByHinge = new Map<HingeRuntime, number>();
    levels.forEach((ordem, i) => {
      const local = unfoldLevelProgress(unfold01, n, i);
      for (const h of hinges.filter((x) => x.ordem === ordem)) {
        openByHinge.set(h, local);
        const closedDeg = effectiveClosedDeg(
          CLOSED_DEG,
          h.chainIndex,
          hingeCount,
        );
        const angle = closedAngleRad(closedDeg, h.sign, local);
        if (h.axis === "y") {
          h.group.rotation.y = angle;
          h.group.rotation.x = 0;
        } else {
          h.group.rotation.x = -angle;
          h.group.rotation.y = 0;
        }
      }
    });
    // Z dinâmico: fechado empilha; aberto ≈ coplanar
    for (const h of hinges) {
      const open01 = openByHinge.get(h) ?? 0;
      const stackIndex = h.chainIndex + 1;
      h.panelGroup.position.z =
        h.stackSign * thickness * stackIndex * (1 - open01);
    }
    recenterPivot();
  };

  const recenterPivot = () => {
    const sx = orbitGroup.rotation.x;
    const sy = orbitGroup.rotation.y;
    const sz = orbitGroup.rotation.z;
    orbitGroup.rotation.set(0, 0, 0);
    orbitGroup.updateMatrixWorld(true);
    pivotGroup.position.set(0, 0, 0);
    contentGroup.updateWorldMatrix(true, true);
    box.setFromObject(contentGroup);
    if (!box.isEmpty()) {
      box.getCenter(center);
      pivotGroup.position.set(-center.x, -center.y, -center.z);
    }
    orbitGroup.rotation.set(sx, sy, sz);
    orbitGroup.updateMatrixWorld(true);
  };

  let rotX = DEFAULT_ROT_X;
  let rotY = DEFAULT_ROT_Y;
  const setOrbit = (x: number, y: number) => {
    rotX = x;
    rotY = y;
    orbitGroup.rotation.order = "YXZ";
    orbitGroup.rotation.x = rotX;
    orbitGroup.rotation.y = rotY;
  };
  setOrbit(DEFAULT_ROT_X, DEFAULT_ROT_Y);
  setHingeAnglesFromUnfold(0);

  const resize = (width: number, height: number) => {
    const w = Math.max(1, width);
    const h = Math.max(1, height);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
    const fit = maxDim * 1.15;
    const dist =
      fit / 2 / Math.tan((camera.fov * Math.PI) / 360) / camera.aspect;
    const distV = fit / 2 / Math.tan((camera.fov * Math.PI) / 360);
    camera.position.z = Math.max(dist, distV) * 1.15;
  };

  const render = () => {
    renderer.render(scene, camera);
  };

  const pickHingeNear = (ndcX: number, ndcY: number): HingeRuntime | null => {
    raycaster.setFromCamera(new THREE.Vector2(ndcX, ndcY), camera);
    const hits = raycaster.intersectObjects(built!.meshes, false);
    if (hits.length === 0) return null;
    const point = hits[0]!.point.clone();
    let best: HingeRuntime | null = null;
    let bestDist = HINGE_HIT_MM;
    const tmp = new THREE.Vector3();
    for (const h of hinges) {
      h.group.getWorldPosition(tmp);
      let d: number;
      if (h.axis === "y") {
        d = Math.hypot(point.x - tmp.x, point.z - tmp.z);
      } else {
        d = Math.hypot(point.y - tmp.y, point.z - tmp.z);
      }
      if (d < bestDist) {
        bestDist = d;
        best = h;
      }
    }
    return best;
  };

  const dispose = () => {
    for (const d of disposables) {
      try {
        d.dispose();
      } catch {
        // ignore
      }
    }
    renderer.dispose();
  };

  return {
    renderer,
    scene,
    camera,
    orbitGroup,
    pivotGroup,
    contentGroup,
    hinges,
    panelMeshes: built.meshes,
    raycaster,
    disposables,
    setOrbit,
    setHingeAnglesFromUnfold,
    recenterPivot,
    resize,
    render,
    dispose,
    pickHingeNear,
  };
}

export { hingeKey };
