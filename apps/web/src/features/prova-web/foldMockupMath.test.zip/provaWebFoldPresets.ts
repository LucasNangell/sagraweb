import type {
  FoldDobra,
  FoldPaginasSeq,
  FoldPresetId,
  FoldSentido,
  ProvaWebFolhetoCrop,
} from "@/api/provaWeb";
import { emptyCropSides } from "@/api/provaWeb";

import {
  defaultSequenciaPaginas,
  normalizeSequenciaPaginas,
  sequenciaIsDefault,
} from "./foldMockupMath";

const MIN_PANEL_MM = 15;
const MIN_GAP_MM = 8;

/** eixo, fraction of usable span, sentido, ordem */
const PRESET_FRACTIONS: Record<
  FoldPresetId,
  Array<[FoldDobra["eixo"], number, FoldSentido, number]>
> = {
  biparte_vertical: [["vertical", 0.5, "valley", 1]],
  biparte_horizontal: [["horizontal", 0.5, "valley", 1]],
  triptico_vertical: [
    ["vertical", 1 / 3, "valley", 1],
    ["vertical", 2 / 3, "mountain", 2],
  ],
  triptico_horizontal: [
    ["horizontal", 1 / 3, "valley", 1],
    ["horizontal", 2 / 3, "mountain", 2],
  ],
  quad_vertical: [
    ["vertical", 0.25, "valley", 1],
    ["vertical", 0.5, "mountain", 2],
    ["vertical", 0.75, "valley", 3],
  ],
  sanfona_vertical: [
    ["vertical", 0.25, "valley", 1],
    ["vertical", 0.5, "mountain", 2],
    ["vertical", 0.75, "valley", 3],
  ],
  cruzado: [
    ["vertical", 0.5, "valley", 1],
    ["horizontal", 0.5, "valley", 2],
  ],
};

export const FOLD_PRESET_OPTIONS: Array<{
  id: FoldPresetId;
  label: string;
  hint: string;
}> = [
  { id: "biparte_vertical", label: "Biparte vertical", hint: "1 dobra no meio" },
  {
    id: "biparte_horizontal",
    label: "Biparte horizontal",
    hint: "1 dobra horizontal",
  },
  { id: "triptico_vertical", label: "Tríptico vertical", hint: "2 dobras · 3 faces" },
  {
    id: "triptico_horizontal",
    label: "Tríptico horizontal",
    hint: "2 dobras · 3 faces",
  },
  { id: "quad_vertical", label: "Quádruplo vertical", hint: "3 dobras · 4 faces" },
  {
    id: "sanfona_vertical",
    label: "Sanfona",
    hint: "3 dobras alternadas",
  },
  { id: "cruzado", label: "Cruzado", hint: "V + H no centro" },
];

export const FOLD_LINE_COLORS = [
  "#7c3aed",
  "#ea580c",
  "#0d9488",
  "#db2777",
  "#2563eb",
];

export function dobrasFromPreset(
  preset: FoldPresetId,
  widthMm: number,
  heightMm: number,
): FoldDobra[] {
  const specs = PRESET_FRACTIONS[preset] ?? PRESET_FRACTIONS.biparte_vertical;
  return specs.map(([eixo, frac, sentido, ordem], i) => {
    const span = eixo === "vertical" ? widthMm : heightMm;
    return {
      id: `d${i + 1}`,
      eixo,
      posicaoMm: Math.round(span * frac * 10) / 10,
      sentido,
      ordem,
    };
  });
}

export function clampDobraPosicao(
  posicaoMm: number,
  eixo: FoldDobra["eixo"],
  usableW: number,
  usableH: number,
): number {
  const span = eixo === "vertical" ? usableW : usableH;
  const lo = MIN_GAP_MM / 2;
  const hi = Math.max(lo, span - MIN_GAP_MM / 2);
  return Math.round(Math.max(lo, Math.min(hi, posicaoMm)) * 10) / 10;
}

export function usableAfterCrop(
  pageW: number,
  pageH: number,
  crop: { top: number; right: number; bottom: number; left: number },
): { w: number; h: number } {
  return {
    w: Math.max(MIN_PANEL_MM, pageW - crop.left - crop.right),
    h: Math.max(MIN_PANEL_MM, pageH - crop.top - crop.bottom),
  };
}

/** Painéis ≈ (cortes V+1) × (cortes H+1). */
export function panelCountFromDobras(dobras: FoldDobra[]): number {
  const v = new Set(
    dobras.filter((d) => d.eixo === "vertical").map((d) => d.posicaoMm),
  ).size;
  const h = new Set(
    dobras.filter((d) => d.eixo === "horizontal").map((d) => d.posicaoMm),
  ).size;
  return Math.max(1, (v + 1) * (h + 1));
}

export function syncSequenciaPaginas(
  prev: FoldPaginasSeq | undefined,
  panelCount: number,
  hasVerso: boolean,
): FoldPaginasSeq {
  if (!prev || sequenciaIsDefault(prev, prev.frente.length, prev.verso != null)) {
    return defaultSequenciaPaginas(panelCount, hasVerso);
  }
  return normalizeSequenciaPaginas(prev, panelCount, hasVerso);
}

export function defaultFolhetoCrop(
  pageWidthMm = 210,
  pageHeightMm = 297,
): ProvaWebFolhetoCrop {
  const crop = emptyCropSides("trimbox");
  const { w, h } = usableAfterCrop(pageWidthMm, pageHeightMm, crop);
  const dobras = dobrasFromPreset("biparte_vertical", w, h);
  const n = panelCountFromDobras(dobras);
  return {
    preset: "biparte_vertical",
    crop,
    dobras,
    pageFrente: 0,
    pageVerso: 1,
    sequenciaPaginas: defaultSequenciaPaginas(n, true),
  };
}

export function applyPresetToFolheto(
  folheto: ProvaWebFolhetoCrop,
  preset: FoldPresetId,
  pageWidthMm: number,
  pageHeightMm: number,
): ProvaWebFolhetoCrop {
  const { w, h } = usableAfterCrop(pageWidthMm, pageHeightMm, folheto.crop);
  const dobras = dobrasFromPreset(preset, w, h);
  const n = panelCountFromDobras(dobras);
  const hasVerso = folheto.pageVerso != null;
  return {
    ...folheto,
    preset,
    dobras,
    sequenciaPaginas: syncSequenciaPaginas(
      folheto.sequenciaPaginas,
      n,
      hasVerso,
    ),
  };
}
